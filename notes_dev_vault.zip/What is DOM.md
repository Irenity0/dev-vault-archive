DOM (Document Object Model) is a programming interface that allows (javascript) scripts to interact with the HTML document.
- It represents the document's structure as a tree of objects
- Lets the script access and modify it's structure, style and content
- allows dynamic content updates
- ensures cross-platform compatibility

