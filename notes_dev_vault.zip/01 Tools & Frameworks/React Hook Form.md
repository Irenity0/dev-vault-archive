#react #library

### Installation

```
npm i --save react-hook-form
```

import

```
import { useForm } from "react-hook-form";
```

