
| u_id | name            | email              | gender | age | dob        |
| ---- | --------------- | ------------------ | ------ | --- | ---------- |
| 1    | ire             | ire@gmail          | female | 16  | 2009-01-01 |
| 2    | Naruto Uzumaki  | naruto@leaf        | male   | 17  | 2007-10-10 |
| 3    | Mikasa Ackerman | mikasa@paradis     | female | 19  | 2006-02-10 |
| 4    | L Lawliet       | l@wammyhouse       | male   | 24  | 2000-06-06 |
| 5    | Levi Ackerman   | levi@scoutregiment | male   | 30  | 1995-12-25 |
👆 --> column/attribute
- the words used in the column header are called _constraint_
- 1 entire row is called _row/tuple/record_
- collection of column is called _degree_

