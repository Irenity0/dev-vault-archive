[[What is JavaScript]]
[[JavaScript Data Types (Primitives & Non-primitives)]]
