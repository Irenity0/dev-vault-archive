A data type in a programming language refers to a characteristic that defines the nature of the value that a data element has. Some common examples include string, integer, character, and boolean.

[[JavaScript Data Types (Primitives & Non-primitives)]]