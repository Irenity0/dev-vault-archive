### CATEGORY 001
[https://docs.google.com/document/d/1f3tbugV_D0CATzbteer6reXLVWmtoAIIX4MaffV48kI/edit?usp=drive_link](https://docs.google.com/document/d/1f3tbugV_D0CATzbteer6reXLVWmtoAIIX4MaffV48kI/edit?usp=drive_link)

[https://docs.google.com/document/d/12kC-xqzNkbCwVesKPPfMG8gZA3ADuk00yVSWjzkOBlY/edit?usp=drive_link](https://docs.google.com/document/d/12kC-xqzNkbCwVesKPPfMG8gZA3ADuk00yVSWjzkOBlY/edit?usp=drive_link)

### CATEGORY 002
[https://docs.google.com/document/d/14uUAzQQPx9hz5fynr72vOX8vXT01t7gp7IFsjeg9sg4/edit?usp=drive_link](https://docs.google.com/document/d/14uUAzQQPx9hz5fynr72vOX8vXT01t7gp7IFsjeg9sg4/edit?usp=drive_link)

[https://docs.google.com/document/d/12wCc9X3gY40gPUDqDoEcMv7cJn3qubxNcuW4qM3FlIA/edit?usp=drive_link](https://docs.google.com/document/d/12wCc9X3gY40gPUDqDoEcMv7cJn3qubxNcuW4qM3FlIA/edit?usp=drive_link)

### CATEGORY 003
[https://docs.google.com/document/d/1uck_6gjiW22ytQMUEdznPxuxX4XB9wDz6fHJroTqCps/edit?usp=drive_link](https://docs.google.com/document/d/1uck_6gjiW22ytQMUEdznPxuxX4XB9wDz6fHJroTqCps/edit?usp=drive_link)

[https://docs.google.com/document/d/1BKueQQMgAm8tBDrEeC_g0VZw9Ls773p2oD9EAARLX3Y/edit?usp=drive_link](https://docs.google.com/document/d/1BKueQQMgAm8tBDrEeC_g0VZw9Ls773p2oD9EAARLX3Y/edit?usp=drive_link)

### CATEGORY 004

[https://docs.google.com/document/d/1ErVVKPWEMzrmOn4bp18Vba0nfUpK-KZpqcTvSNffLKU/edit?usp=drive_link](https://docs.google.com/document/d/1ErVVKPWEMzrmOn4bp18Vba0nfUpK-KZpqcTvSNffLKU/edit?usp=drive_link)

[https://docs.google.com/document/d/1qQJHyVIB_Jdrxr9htu2ocB_b9__V9d6f_p-yjKrbMxM/edit?usp=drive_link](https://docs.google.com/document/d/1qQJHyVIB_Jdrxr9htu2ocB_b9__V9d6f_p-yjKrbMxM/edit?usp=drive_link)

### CATEGORY 005

[https://docs.google.com/document/d/1Ueydif7eXywT6rCkp2lF1Q85DjxgaNpQ60w5HDEIG8Y/edit?usp=drive_link](https://docs.google.com/document/d/1Ueydif7eXywT6rCkp2lF1Q85DjxgaNpQ60w5HDEIG8Y/edit?usp=drive_link)

[https://docs.google.com/document/d/1YWZYI6XlNVApjpsZEdZQ_LymqOHSqjIMp-WbuCw7zs4/edit?usp=drive_link](https://docs.google.com/document/d/1YWZYI6XlNVApjpsZEdZQ_LymqOHSqjIMp-WbuCw7zs4/edit?usp=drive_link)

