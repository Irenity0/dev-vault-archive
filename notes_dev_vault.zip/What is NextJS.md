NextJS is a React framework that gives you the building blocks to create web applications
By framework, we mean Nextjs handles the tooling and configuration for React
It provides additional structure, features and optimization for your application
