#level2

# What is Database?
A database is a structured collection of related data that represents some real world entities and are organized for efficient retrieval storage and management